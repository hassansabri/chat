Integration test between nodeJS and PHP

This is just a simple chat application, where all database and pages are managed by PHP.
NodeJS is used for realtime refresh

It is basically just a test project, but the logic of the application can be used for a lot of purposes (realtime notifications, ...) and easily deployed in another project.

I will try to update and improve it as soon as possible.
